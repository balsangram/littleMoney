import React from 'react'

const MerchantSettings = () => {
  return (
    <div>MerchantSettings</div>
  )
}

export default MerchantSettings
