const Footer = () => {
    return <div className="flex justify-center w-3/4  absolute bottom-0 dark:text-white-dark text-center ltr:sm:text-left rtl:sm:text-right p-6 pt-0 mx-auto ">© {new Date().getFullYear()} Little Money Technologies Pvt. Ltd      All rights reserved.</div>;
   
};

export default Footer;
