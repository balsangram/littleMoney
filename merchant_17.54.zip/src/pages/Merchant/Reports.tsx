import React from 'react'

const MerchantReports = () => {
  return (
    <div>MerchantReports</div>
  )
}

export default MerchantReports
